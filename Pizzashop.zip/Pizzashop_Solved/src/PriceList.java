

public interface PriceList {
	int SMALL_PIZZA_PRICE=200;
	int MEDIUM_PIZZA_PRICE=300;
	int LARGE_PIZZA_PRICE=400;
	int TOPPINGS_BASE_PRICE=50;

}
