
public class Menu 
{
    public void menuCard()
    {
        System.out.println("\t\t\t    Menu Card");
        System.out.println("------------------------------------------------------------------");
        System.out.println("|  Veg\t\t\tPrices  |  Non-Veg\t\tPrices  |");
        System.out.println("------------------------------------------------------------------");
        System.out.println("|  I. Sizes\t\t\t|  I. Sizes\t\t\t|");
        System.out.println("|  \t1. Small\t 200\t|  \t1. Small\t 200\t|");
        System.out.println("|  \t2. Medium\t 300\t|  \t2. Medium\t 300\t|");
        System.out.println("|  \t3. Large\t 400\t|  \t3. Large\t 400\t|");
        System.out.println("|  II. Toppings\t\t\t|  II. Toppings\t\t\t|");
        System.out.println("|  \t1. Olives\t 50\t|  \t1. Olives\t 50\t|");
        System.out.println("|  \t2. Extra Cheese\t 50\t|  \t2. Extra Cheese\t 50\t|");
        System.out.println("|  \t3. Onion\t 50\t|  \t3. Onion\t 50\t|");
        System.out.println("|  \t4. Tomatoes\t 50\t|  \t4. Tomatoes\t 50\t|");
        System.out.println("|  \t5. Pineapple\t 50\t|  \t5. Pineapple\t 50\t|");
        System.out.println("------------------------------------------------------------------");
    }
}
