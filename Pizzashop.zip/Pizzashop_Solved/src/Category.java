
public interface Category {

	public static final  int VEG=1;
	public static final  int NON_VEG=2;

}
